import os
import math
import sys
print "*.py monomer_name outputname num"
monomer = sys.argv[1] + '.pdb'
outputfile = sys.argv[2] + '.pdb'
num = int(sys.argv[3])
chain = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P']
with open(monomer,'r') as fopen:
   lines = fopen.readlines()
dist = 0
for line in lines:
  if line.split()[0] == 'ATOM':
    print line[30:38]
    if abs(float(line[30:38])) > dist:
       distx = abs(float(line[30:37]))
    if abs(float(line[38:46])) > dist:
       disty = abs(float(line[38:45]))
    if abs(float(line[46:54])) > dist:
       distz = abs(float(line[46:53]))
       resi_num = int(line.split()[1])
       relic = line[11:26]
#dist += 10.000
#print dist
data = ''
distx = -0.849
disty = 0.767
distz = 4.71
for i in range(num):
    for line in lines:
     if  line.split()[0] == 'ATOM':
         x= format(float(line[30:37]) + i*distx,'.3f')
         y= format(float(line[38:45]) + i*disty,'.3f')
         z= format(float(line[46:53]) + i*distz,'.3f')
         print i
         print chain[i]
         single = line[0:21] + chain[i] + line[22:30] + str(x).rjust(8,' ') + str(y).rjust(8,' ') + str(z).rjust(8,' ') + line[54:80] + '\n'
     else:
         single = 'TER    ' + str(resi_num + 1)   + relic[0:10] + chain[i] + relic[11:15] + '\n'
     data += single
with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
