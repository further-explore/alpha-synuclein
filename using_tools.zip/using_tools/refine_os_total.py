import os
import sys
inputfile = sys.argv[1]
outputfile = sys.argv[2]
with open(inputfile,'r') as fopen:
     lines = fopen.readlines()
data = ''
for line in lines:
   if len(line.split()) == 1:
      data += line.split()[0] + ' 0\n'
   else:
      data += line
with open (outputfile,'w') as fwrite:
     fwrite.writelines(data)
