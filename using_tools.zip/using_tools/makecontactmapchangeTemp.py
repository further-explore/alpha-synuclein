# usr/bin/env python3
import os
import sys
import random
import re
print('python select_structure_Energy_data.py PdbID template work_name appendix')

Dir_download = '/scratch/xc25/download'
PdbID = sys.argv[1]
Temp = sys.argv[2]
Work = sys.argv[3]
Appd = sys.argv[4]
if Work == 'ER':
   Work_whole = PdbID + '-' + Work
else:
   Work_whole = PdbID + '-' + Temp + '-'+ Work
print(Work_whole)
SumD = Work_whole + '-' + Appd
Dir_Target = '/home/xun/Downloads/Backup/' + PdbID + '/' + SumD + '/Basefile'
for i in range(20):
    Dir_object =  '/home/xun/Downloads/Backup/' + PdbID + '/' + SumD + '/' + Work_whole + str(i)
    os.chdir("%s"%(Dir_object))
    os.system("cp %s/*.pdb %s/"%(Dir_Target,Dir_object))
    os.system("cp %s/*.seq %s/"%(Dir_Target,Dir_object))
    os.system("python /home/xun/Downloads/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py dump.lammpstrj %s-whole.pdb %s-HO.seq"%(PdbID,PdbID))
    os.system("python /home/xun/use_tools/ContactFoldingTemperature_Q.py 6000 108 %s-whole.pdb %s.pdb 500 200 10"%(PdbID,PdbID))






