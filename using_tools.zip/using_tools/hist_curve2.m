
PdbID = 'PaaA2'
Appd = '1.5'
Flag = 'fragmem_on'
Flag2 = 'fragmem-on'
Temp = '300K'
fontsize = 25
set(gca,'Fontsize',fontsize);
filename1 = ['/home/xun/Downloads/data_sum/download-12/',PdbID,'/',Flag,'/',PdbID,'-',Appd,'/rg.txt']
filename2 = ['/home/xun/Downloads/data_sum/download-12/',PdbID,'/',Flag,'/',PdbID,'-',Appd,'/Dee.txt']
[data1,limit] = importdata(filename1);
[data2,limit] = importdata(filename2);
[P,Rg,Dee] = histcounts2(data1,data2,50);
P = P/10000;
Rg = linspace(min(data1),max(data1),50);
Dee = linspace(min(data2),max(data2),50);
%p = interp2(data1,data2,P,Rg,Dee)
x = Rg;
y = Dee;
Z = P;
n = 50
%contour(Rg,Dee,P)% n = 50;
%figure(1);
%plot(Rg,Dee,'bo');
%figure(2);
xi = linspace(min(x(:)), max(x(:)), n);
yi = linspace(min(y(:)), max(y(:)), n);
 
 
xr = interp1(xi, 0.5:numel(xi)-0.5, x, 'nearest');
yr = interp1(yi, 0.5:numel(yi)-0.5, y, 'nearest');
%Z = accumarray([yr xr] + 0.5, 1);
P(P==0) = nan
contourf(Rg, Dee, log2(P+1),20,'edgecolor','none');

Z(Z==0) = nan;
%contourf(xi, yi, log2(Z+1),20,'edgecolor','none');
colormap(jet);colorbar
xlim([12,30]);
ylim([0,90]);
set(gca,'XTick',[12:2:30])
xlabel('Rg','Fontsize',fontsize)
ylabel('Dee','Fontsize',fontsize)
title([PdbID,'-',Temp,'-',Flag2,'-Rama = ',Appd],'Fontsize',14)
saveas(gcf,['/home/xun/data_analysis/',PdbID,'-',Temp,'-',Flag2,'-',Appd,'.png'])
