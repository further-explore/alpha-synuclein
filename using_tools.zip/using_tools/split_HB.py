import os
import sys
import numpy as np
inputfile = sys.argv[1]
matrix = np.loadtxt(inputfile)
intra_antipara=matrix[:,0]
intra_para=matrix[:,1]
inter_antipara=matrix[:,2]
inter_para=matrix[:,3]
inter_HB=inter_para+inter_antipara
intra_HB=intra_para+intra_antipara
HB = inter_HB+intra_HB
#f = file("intra_antipara","wb")
np.savetxt("intra_antipara",intra_antipara, fmt="%d",delimiter = " ",newline='\n',header='',footer='',comments='#' )
np.savetxt("intra_para",intra_para, fmt="%d",delimiter = " ",newline='\n',header='',footer='',comments='#' )
np.savetxt("inter_antipara",inter_antipara, fmt="%d",delimiter = " ",newline='\n',header='',footer='',comments='#' )
np.savetxt("inter_para",inter_para, fmt="%d",delimiter = " ",newline='\n',header='',footer='',comments='#' )
np.savetxt("inter_HB",inter_HB, fmt="%d",delimiter = " ",newline='\n',header='',footer='',comments='#' )
np.savetxt("intra_HB",intra_HB, fmt="%d",delimiter = " ",newline='\n',header='',footer='',comments='#' )
np.savetxt("HB",HB, fmt="%d",delimiter = " ",newline='\n',header='',footer='',comments='#' )

#f.close()
#f = file("intra_para","wb")
#np.save(f,intra_para)
#f.close()
#f = file("inter_antipara","wb")
#np.save(f,inter_antipara)
#f.close()
#f = file("inter_para","wb")
#np.save(f,inter_para)
#f.close()

