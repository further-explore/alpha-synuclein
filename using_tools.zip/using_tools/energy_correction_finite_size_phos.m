  T = 300
disp(T)
pdb_array= { 'ten1'};
sim_labels = [14 7 6 4];
%qa_name ='Contact_Qregion';%new rxn co
%qa_name ='tc_total';%new rxn co
qa_name ='osl_total';%new rxn co
%qa_name = 'os_totalxxx'
binN=10;
color={'r','m','g','b','y','c','k'};
dih_range=16:22;
n_T=16;
cv=zeros(n_T,1); cm=colormap(jet(n_T))
curve_shift_flag=1; q0_shift=0.55;
%; qmono_flag =0;

%if qmono_flag == 1
%    path = sprintf('~/work/mdbox/qbias_mono/%s', pdbID_upper);
%else
%    path = sprintf('~/work/mdbox/qbias/%s',      pdbID_upper);
%end
cutoff=100;
scrnsize = get(0,'ScreenSize'); 
%figure('position', [1 scrnsize(4) 0.3*scrnsize(3) 0.4*scrnsize(4)]), hold on
fsize=40; tsize=16; %mr=3; mc=2;
%for i_list = 1:length(T_list)
    %T = T_list(i_list);
    %subplot(mr, mc, i_list),
    %grid on, hold on, set(gca, 'fontsize', tsize); xlabel('Q', 'fontsize', fsize); ylabel('F (kcal/mol)', 'fontsize', fsize); 
    for i_label=1
        sim_label = sim_labels(i_label);
        pdbID_upper = pdb_array{i_label};
        path = sprintf('/home/xun/alpha-synuclein/%s',pdbID_upper);
        %title([pdbID_upper, ' ', num2str(T), 'K'], 'fontsize', fsize);
        
        filename = sprintf('%s/%s',path, qa_name); qa = load(filename);        
        if strcmp(qa_name,'dih')
            qa=(mean(qa(:,dih_range)'))';
        end
        %qb = qa(:,2);
        qa = qa(:,1);
        %load q
        filename = sprintf('%s/p_total',path); q = load(filename);
        %if qo_flag == 1
        %    filename = sprintf('%s/qo_%d',path, sim_label); qo = load(filename); 
        %end
        Nsample = length(q);    

        %load pmf file and calculate pi_sample
        filename=sprintf('%s/%s_%d_pmf2.dat',path,pdbID_upper, T);        

        FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
        dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
        Py=exp(-Fy/(0.001987*T)); P_norm = sum(Py); Py=Py/P_norm;
        pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);
        %calculate pi_sample
        for i_bin= 1:nbin
            qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
            ids = find( q >= qi_min & q < qi_max ) ;    
            ni_sample(i_bin) = length(ids);        
            if ni_sample(i_bin) > 0
                pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
            end
        end    
        fprintf('probability = %.3f\n', sum(pi_sample));                        

        qa_lin=linspace(min(qa), max(qa),binN);
        count_qa=zeros(binN,1);
        [~,bin_index_x]=histc(qa, qa_lin);
        for i_sample=1:Nsample
           % if qb(i_sample) < 3
            x=bin_index_x(i_sample);
            count_qa(x) = count_qa(x) + pi_sample(i_sample);
           % endData_dealing/tau_R134
        end
        fprintf('Total probability for new coordinate is %.3f\n',sum(count_qa));
        F_qa=-0.001987*T*log(count_qa);
        %F_qa(4)=F_qa(4)*0.15 + F_qa(5)*0.85
        ids = (F_qa>= cutoff); F_qa(ids) = cutoff;
        %F_qa=F_qa;
        if curve_shift_flag==0
            Fmin = min(F_qa); id_shift = find( F_qa == Fmin );
        else
            [~,id_shift]=min(abs(qa_lin-q0_shift));
        end
        %xlim([0 1]);
        %id_shift(1)=35;
        %plot(FF(:,1), FF(:,2)-FF(id_shift(1),2), 'linewidth', 3); 
        %if i_list == 1
        %    legend('T400','T420','T440','T450','fontsize',fsize);
        %end
        %dddd=smooth(F_qa-F_qa(id_shift(1)),kao)
        %print qa_lin
        index = 2 
        qa_lin=[1,2,3,4,5,6,7,8,9,10]
        plot(qa_lin, F_qa-F_qa(id_shift(1)),'color', cm(index,:),'MarkerFacecolor',cm(index,:),'Marker','d','markersize',5,'LineStyle','--', 'linewidth', 6);   hold on;
        % change for -nktln(c1/c0)
        %plot(QA_LINs, F_QAs,'color', cm(index,:), 'linewidth', 4);   hold on;
        fsize=30; tsize=16;%xlim([0,110]);
        qa_name='Oligmer size'
        xlabel(qa_name, 'fontsize', fsize); ylabel('Free energy (kcal/mol)', 'fontsize', fsize); title(['Free energy with ',qa_name,' kcal/mol'], 'fontsize', fsize);
        %set(gca,'fontsize',fsize)
        %xlim([0,52])
    end
        %qa_lin2=linspace(min(qa), max(qa)-1,binN-1)
        qa_lin2 =[1,2,3,4,5,6,7,8,9]
        %qa_lin3={0.039,0.134,0.0324,0.510,0.976,0.487,0.984}
        for i =1 :9
            if i ~= 10
             F_QA(i) = F_qa(i) + qa_lin2(i)*0.001987*T*(log(10-qa_lin2(i))-log(10));
             if i ~= 1
                 F_QA(i) = F_QA(i)+0
             end
            else
             F_QA(i) = F_qa(i)- qa_lin2(i)*0.001987*T*ln(6)
            end
        end
        
        %for i =1 :7
         %   if i ~= 8
         %    F_QAx(i) = F_QA(i) + 0.001987*T*log(1-qa_lin3{i});
          %  else
           %  F_QAx(i) = F_QA(i)- qa_lin2(i)*0.001987*T*log(8)
           % end
       % end
        %ids = (F_qa>= cutoff)
        %F_qa(ids) = cutoff
        %F_qa=F_qa;
        if curve_shift_flag==0
            Fmin = min(F_AQ); id_shift = find( F_QA == Fmin);
        else
            [~,id_shift]=min(abs(qa_lin-q0_shift))
        end
      
        index = 4
        plot(qa_lin2, F_QA-F_QA(id_shift(1)),'color', cm(index,:), 'MarkerFacecolor',cm(index,:),'Marker','d','markersize',5,'LineStyle','-','linewidth', 6);   hold on;
        %plot(qa_lin2, F_QAx-F_QAx(id_shift(1)),'color', cm(index,:), 'Marker','o','LineStyle','-','linewidth', 4);   hold on;
        indexlist = {6,8,10,12,14,18,20,22,24,26}
        concentrationlist = {1,8,30,400}
        markerlist={'s','p','d','h','+','*','.','>','<','^'}
        for i =1:4
            for j = 1:9
              F_QB(j) = F_QA(j)- qa_lin(j)*0.001987*T*log(concentrationlist{i}/133)
            end
            ids = (F_QA>= cutoff)
            F_qa(ids) = cutoff
            F_qa=F_qa;
            if curve_shift_flag==0
               Fmin = min(F_QB); id_shift = find( F_QB== Fmin);
            else
               [~,id_shift]=min(abs(qa_lin-q0_shift))
            end
            
            plot(qa_lin2, F_QB-F_QB(id_shift(1)),'color', cm(indexlist{i},:),'MarkerFacecolor',cm(index,:),'Marker','diamond','markersize',5,'LineStyle','-', 'linewidth', 6);   hold on;    
        end
        %xlim([1,5])
        %title ([' expection with correction '])
        %set(gca, 'FontSize',fsize);
        legend('133uM before correction ','133uM after correction','1uM','8uM','30uM','0.4mM')
        %set(gca,'XTick',[1:1:6])
        set(gca, 'FontSize',fsize*0.5);
        %xlim([1,5])
        xtickslabel([1,2,3,4,5,6,7,8,9,10])
        xlabel('oligmer size','fontsize', fsize)
        ylabel('Free energy(kcal/mol)', 'fontsize', fsize)
        %xlim([1,5])
        %saveas(gcf,[path,'/','2d-',prefix,'-',xname,'-',yname,'.png'])
