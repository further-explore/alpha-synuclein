import os
import sys
import numpy as np

def select_frame2(data1,center1,delta1,data2,center2,delta2):
    fileorder = []
    for i in range(len(data1)):
       if abs(data1[i]-center1) <= delta1 and abs(data2[i]-center2) <= delta2: 
          fileorder.append(i+1)
    return fileorder

def select_frame2_loop(data1,center1,delta1,data2,center2,delta2):
    for i in range(1,200000):
        x = delta1*i
        y = delta2*i
        fileorder = select_frame2(data1,center1,x,data2,center2,y)
        if len(fileorder) != 0:
           return fileorder
def main():
    inputfile1 = sys.argv[1]
    inputfile2 = sys.argv[2]
    center1 = float(sys.argv[3])
    center2 = float(sys.argv[4])
    delta1 = float(sys.argv[5])
    delta2 = float(sys.argv[6])
    data1 = np.loadtxt(inputfile1)
    data2 = np.loadtxt(inputfile2)
    fileorder = select_frame2_loop(data1,center1,delta1,data2,center2,delta2)
    print fileorder

if __name__ == '__main__':
    main()
