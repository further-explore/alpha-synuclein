import os
import sys
import numpy as np

def select_frame1(data1,center1,delta1):
    fileorder = []
    for i in range(len(data1)):
       if abs(data1[i]-center1) <= delta1: 
          fileorder.append(i+1)
    return fileorder

def select_frame1_loop(data1,center1,delta1):
    for i in range(1,200000):
        delta1 = delta1*i
        fileorder = select_frame1(data1,center1,delta1)
        if len(fileorder) != 0:
           return fileorder
def main():
    inputfile = sys.argv[1]
    center1 = float(sys.argv[2])
    delta1 = float(sys.argv[3])
    data1 = np.loadtxt(inputfile)
    fileorder = select_frame1_loop(data1,center1,delta1)
    print fileorder

if __name__ == '__main__':
    main()
