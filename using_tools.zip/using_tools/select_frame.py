import os
import sys
import numpy as np

inputfile1 = sys.argv[1]
inputfile2 = sys.argv[2]
center1 = float(sys.argv[3])
center2 = float(sys.argv[4])
delta1 = float(sys.argv[5])
delta2 = float(sys.argv[6])

data1 = np.loadtxt(inputfile1)
data2 = np.loadtxt(inputfile2)
for i in range(len(data1)):
    if abs(data1[i]-center1) <= delta1 and abs(data2[i]-center2) <= delta2:
       print i+1


