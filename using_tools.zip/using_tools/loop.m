path = '/home/xun/alpha-synuclein/ten1/decouple/ten1'

PdbID = 'ten1';
squeue = {'bending_specificity','basepair_specificity'};
squeue_name = {'bending-specificity','basepair-specificity'};
squeue_name = {'Bindc_total','charge_dna_protein_max_total'};
size = {'large','small'};
T = 300;
color={'r','r','r','m','g','b','b','b','b'};
dih_range=16:22;
n_T=16;
n_contour=50;
cv=zeros(n_T,1); cm=colormap(jet(n_T))
curve_shift_flag=1; q0_shift=0.55;
cutoff=10;
scrnsize = get(0,'ScreenSize'); 
fsize=40; tsize=16;
%qa_name = 'interparad_total';qb_name = 'dDSSP+PAP_total',xname = '# \Detla interchain parallel hydrogen bond';yname = '# \Delta DSSP+PAP'
%qa_name = 'interparad_total';qb_name = 'dDSSP+PAP_total';xname = '# \Delta interchain parallel hydrogen bond';yname = '\Delta DSSP+PAP'
%qa_name = 'interparad_total';qb_name = 'dBurial_total';xname = '# \Delta interchain parallel hydrogen bond';yname = '\Delta Burial'
%qa_name = 'interparad_total';qb_name = 'dWater_total';xname = '# \Delta interchain parallel hydrogen bond';yname = '\Delta Water'
%qa_name = 'interparad_total';qb_name = 'dElec_total';xname = '# \Delta interchain parallel hydrogen bond';yname = '\Delta Elec'

qa_name = 'interantiparad_total';qb_name = 'dDSSP+PAP_total';xname = '# \Delta interchain antiparallel hydrogen bond';yname = '\Delta DSSP+PAP'
qa_name = 'interantiparad_total';qb_name = 'dBurial_total';xname = '# \Delta interchain antiparallel hydrogen bond';yname = '\Delta Burial'
qa_name = 'interantiparad_total';qb_name = 'dWater_total';xname = '# \Delta interchain antiparallel hydrogen bond';yname = '\Delta Water'
qa_name = 'interantiparad_total';qb_name = 'dElec_total';xname = '# \Delta interchain antiparallel hydrogen bond';yname = '\Delta Elec'


qa_name = 'interpara_total';qb_name = 'DSSP+PAP_total';xname = '# interchain parallel hydrogen bond';yname = 'DSSP+PAP'
qa_name = 'interpara_total';qb_name = 'Burial_total';xname = '# interchain parallel hydrogen bond';yname = ' Burial'
qa_name = 'interpara_total';qb_name = 'Water_total';xname = '# interchain parallel hydrogen bond';yname = ' Water'
qa_name = 'interpara_total';qb_name = 'Elec_total';xname = '# interchain parallel hydrogen bond';yname = ' Elec'
qa_name = 'interantipara_total';qb_name = 'DSSP+PAP_total';xname = '# interchain antiparallel hydrogen bond';yname = ' DSSP+PAP'
qa_name = 'interantipara_total';qb_name = 'Burial_total';xname = '# interchain antiparallel hydrogen bond';yname = ' Burial'
qa_name = 'interantipara_total';qb_name = 'Water_total';xname = '# interchain antiparallel hydrogen bond';yname = ' Water'
qa_name = 'interantipara_total';qb_name = 'Elec_total';xname = '# interchain antiparallel hydrogen bond';yname = 'Elec'

qa_name = 'qn_total';qb_name = 'qn-1_total';xname = '# Qw (Nmer)';yname = 'Qw (N-1mer)'


qa_name='interparahb_tips_total';qb_name='interantiparahb_tips_total';xname = '# interchain parallel hydrogen bond (Disordered monomer)',yname='# interchain antiparallel hydrogen bond (Disordered monomer) '
%qa_name='interdeltahb_tips_total';qb_name='DSSP+PAP_total';xname = '# interchain (antiparallel - parallel) hydrogen bond (Disordered monomer)',yname='DSSP+PAP '
%qa_name='interdeltahb_tips_total';qb_name='Burial_total';xname = '# interchain (antiparallel - parallel) hydrogen bond (Disordered monomer)',yname='Burial'
%qa_name='interdeltahb_tips_total';qb_name='Water_total';xname = '# interchain (antiparallel - parallel) hydrogen bond (Disordered monomer)',yname='Water'
%qa_name='interdeltahb_tips_total';qb_name='Elec_total';xname = '# interchain (antiparallel - parallel) hydrogen bond (Disordered monomer)',yname='Elec'
q_name={  'Omf_total' ,'Ohf_total'};xname = '# minimally frustrated interactions ',yname='# highly frustrated interactions'
q_name={  'Ohf_total' ,'interpara_total'};xname = '# highly frustrated interactions ',yname='# interchain parallel hydrogen bond'
q_name={  'Omf_total' ,'interantipara_total'};xname = '# minimally frustrated interactions ',yname='# interchain antiparallel hydrogen bond'
% q_name={  'Omf_total' ,'Burial_total'};xname = '# minimally frustrated interactions ',yname='Burial'
%q_name={  'Ohf_total' ,'DSSP+PAP_total'};xname = '# highly frustrated interactions ',yname='DSSP+PAP'
%q_name={  'Omf_total' ,'Water_total'};xname = '# minimally frustrated interactions ',yname='Water'
%q_name={  'Ohf_total' ,'Elec_total'};xname = '# highly frustrated interactions ',yname='Elec'
%q_name={  'dOmhf_total' ,'dinterpa_total'};xname = '# (minimally -highly) frustrated interactions',yname='#interchain (parallel-antiparallel) hydrogen bond'

%q_name={  'Omf_total' ,'interpara_total'};xname = '# minimally frustrated interactions ',yname='# interchain parallel hydrogen bond'
%q_name={  'Ohf_total' ,'interantipara_total'};xname = '# highly frustrated interactions ',yname='# interchain antiparallel hydrogen bond'
%q_name={  'Ohf_total' ,'Burial_total'};xname = '# highly frustrated interactions ',yname='Burial'
%q_name={  'Omf_total' ,'DSSP+PAP_total'};xname = '# minimally frustrated interactions ',yname='DSSP+PAP'
%q_name={  'Ohf_total' ,'Water_total'};xname = '# highly frustrated interactions ',yname='Water'
%q_name={  'Omf_total' ,'Elec_total'};xname = '# minimally frustrated interactions ',yname='Elec'
binN=20;ObinN=20;
cutoff = 10;
%xnum1=0,xnum2=45
%ynum1=0,ynum2=45
qa_name=q_name{1}; qb_name=q_name{2};
for i=4:7
    figure('position', [1 4*scrnsize(4) 0.25*scrnsize(3) 0.35*scrnsize(4)]);
    filename = sprintf('%s/%s-%d',path, qa_name,i); 
    qa =  load(filename); 
    filename = sprintf('%s/%s-%d',path, qb_name,i); 
    %rg = load('rg_total');
    qb =  load(filename);
    %qb = qb./rg.^3
    
    filename = sprintf('%s/osl_total',path); 
    %rg = load('rg_total');
    qc =  load(filename);
    %Nsample=size(qa,1);
    Nsample=length(qa)
    %assert(Nsample=size(qb,1));
    %load pmf file and calculate pi_sample
    T_i=T; T=T_i;    
    %path = sprintf('/home/xc25/Data_dealing/tau_agggregagtion/tau_9th_3rd')
    filename = sprintf('%s/p_total-%d',path,i); q = load(filename);
    filename=sprintf('%s/ten1_%d_pmf.dat',path, T_i);
    FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
    dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
    Py=exp(-Fy/(0.001987*T_i)); P_norm = sum(Py); Py=Py/P_norm;
    pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);
    %calculate pi_sample
    for i_bin= 1:nbin
        qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
        ids = find( q >= qi_min & q < qi_max ) ;    
        ni_sample(i_bin) = length(ids);        
        if ni_sample(i_bin) > 0
            pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
        end
    end    
    fprintf('probability = %.3f\n', sum(pi_sample));        
    %binN=40;ObinN=40;
    qa_lin=linspace(min(qa), max(qa),ObinN); qb_lin=linspace(min(qb), max(qb),binN); H=zeros(ObinN,binN);
    [~, bin_index_x] = histc(qa, qa_lin); [~, bin_index_y] = histc(qb, qb_lin);
    for i_sample = 1:Nsample
        x=bin_index_x(i_sample); y=bin_index_y(i_sample);
        %if qc(i_sample) > 0
           H(x,y) = H(x,y) + pi_sample(i_sample)*abs((log((10-i+0.05)/10.0)).^i);
        %end
    end
    H=H'; fprintf('sum(sum(H))=%.3f\n', sum(sum(H)));    
    
    F=-0.001987*T*log(H);%ids = (F>= cutoff); F(ids) = cutoff;
    %for i=1:ObinN-1
    %   for j =1:binN
    %        F(j,i) = F(j,i) + i*0.001987*T*(log(10-i)-log(10))%- i*0.001987*T*log(400/133);
    %   end
    %end
    %for j =1:binN
    %        F(j,10) = F(j,10) + i*0.001987*T*(log(10-i+0.001)-log(10)) %-10 * .001987*T*log(400/133);
    %end
       
       
        
    %F(3,4)=13.9
    %F(3,5)=13.9
   %[xnew,ynew]=meshgrid(linspace(min(qa),max(qa),newpoints),linspace(min(qb),max(qb),Onewpoints))
    ids = (F>= cutoff-1); F(ids) = cutoff+1;
   % znew=interp2(qa_lin,qb_lin,F,xnew,ynew,'spline')
   % ids = (znew>= cutoff); znew(ids) = cutoff+1;
    %[~,h] = contourf(xnew, ynew,znew,n_contour,'edgecolor','none');

    [~,h] = contourf(qa_lin, qb_lin,F,n_contour,'edgecolor','none');shading flat,
    colormap(jet);
    cm=colormap;
    cm(64, :) = [1 1 1]
    %cm(63, :) = [1 1 1];
    colormap(cm);
    fsize=20
    colorbar;
    %xlim([xnum1,xnum2])
    %ylim([ynum1,ynum2])
    xlabel(xname,'fontsize',fsize/1.5)
    ylabel(yname,'fontsize',fsize/1.5)
    saveas(gcf,['/home/xun/trash/figure_aS/',num2str(i),qa_name,qb_name,'2d.png'])
end