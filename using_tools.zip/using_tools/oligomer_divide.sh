oligomer_size=( "monomer" "dimer" "trimer" "tetramer" "pentamer" "hexamer"  )
file=( "p_total" "e_total" "qo_total" "inter_antipara_total" "inter_para_total" "intra_antipara_total" "intra_para_total" "inter_total" "intra_total" "tc_total" "ecoul_total" )
for i in $(seq 1 6);do
    let "j=i-1"
    #echo ${oligomer_size[$j]}
    for  filename in ${file[@]};do
       #  echo $filename
         python /home/xc25/using_tools/data_selected_based_critia.py first_oligomer_total $filename ${oligomer_size[$j]} $i
done
done

