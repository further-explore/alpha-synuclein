import os
import math
import sys
print "*.py monomer_name outputname num"
monomer1 = sys.argv[1] + '.pdb'
num1 = int(sys.argv[2])
num2 = int(sys.argv[4])
monomer2 = sys.argv[3] + '.pdb'
outputfile = sys.argv[5] + '.pdb'
#num = int(sys.argv[3])
chain = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
with open(monomer1,'r') as fopen:
   lines1 = fopen.readlines()
distx = 0
disty = 0
distz = 0
for line in lines1:
  if line.split()[0] != 'END':
    if abs(float(line[30:38])) > distx:
       distx = abs(float(line[30:37]))
    if abs(float(line[38:46])) > disty:
       disty = abs(float(line[38:45]))
    if abs(float(line[46:54])) > distz:
       distz = abs(float(line[46:53]))
       resi_num1 = int(line.split()[1])
       relic1 = line[11:26]
with open(monomer2,'r') as fopen:
   lines2 = fopen.readlines()
for line in lines2:
  if line.split()[0] != 'END':
    if abs(float(line[30:38])) > distx:
       distx = abs(float(line[30:37]))
    if abs(float(line[38:46])) > disty:
       disty = abs(float(line[38:45]))
    if abs(float(line[46:54])) > distz:
       distz = abs(float(line[46:53]))
       resi_num2 = int(line.split()[1])
       relic2 = line[11:26]
#dist += 10.000
#print dist
data = ''
for i in range(num1+num2):
   if i%2 == 0:
    for line in lines1:
     if  line.split()[0] != 'END':
         x= format(float(line[30:37]) + (i//3 + i%3//1 )*distx,'.3f')
         y= format(float(line[38:45]) + (i//3 + i%3//2 )*disty,'.3f')
         z= format(float(line[46:53]) + (i//3  )*distz,'.3f')
         print i
         print chain[i]
         single = line[0:21] + chain[i] + line[22:30] + str(x).rjust(8,' ') + str(y).rjust(8,' ') + str(z).rjust(8,' ') + line[54:80] + '\n'
     else:
         single = 'TER    ' + str(resi_num1 + 1)   + relic1[0:10] + chain[i] + relic1[11:15] + '\n'
     data += single
   else:
    for line in lines2:
     if  line.split()[0] != 'END':
         x= format(float(line[30:37]) + (i//3 + i%3//1 )*distx,'.3f')
         y= format(float(line[38:45]) + (i//3 + i%3//2 )*disty,'.3f')
         z= format(float(line[46:53]) + (i//3  )*distz,'.3f')
         print i
         print chain[i]
         single = line[0:21] + chain[i] + line[22:30] + str(x).rjust(8,' ') + str(y).rjust(8,' ') + str(z).rjust(8,' ') + line[54:80] + '\n'
     else:
         single = "END"
         #single = 'TER    ' + str(resi_num2 + 1)   + relic2[0:10] + chain[i] + relic2[11:15] + '\n'
     data += single

with open(outputfile,'w') as fwrite:
     fwrite.writelines(data)
