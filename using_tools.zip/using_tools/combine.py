# /user/bin/env python3
import os
import sys
import re
import commands
PdbID = sys.argv[1] 
filename = sys.argv[2]
num = int(sys.argv[3])
position = int(sys.argv[4])
if (filename == 'qo') or (filename == 'qw') or (filename == 'rg'):
   Flag = 1
else:
   Flag = 0
os.system("mkdir download")
DirW = '/scratch/xc25/download'
os.chdir("%s"%(DirW))
os.system("mkdir %s"%(PdbID))
DirL = DirW + '/' + PdbID
os.chdir("%s"%(DirL))
Dirw = '/scratch/xc25/Qbiastried'
Dirl = Dirw + '/' + PdbID + '-Qbias'
outputfile = DirL + '/' + PdbID + '-' +  filename +  '.txt'
data = ''
if Flag == 1 :
   for i in range(num):
     j = i + 1
     readfile = Dirl + '/' + PdbID  + str(j) + '/' + filename
     with open (readfile,'r') as fopen:
       for line in fopen.readlines():
           data += line.split('\n')[0] + ' '
           
else:
   for i in range(num):
    j = i + 1
    readfile = Dirl + '/' + PdbID  + str(j) + '/' + filename
    with open (readfile,'r') as fopen:
       for line in fopen.readlines():
           if line.split()[0] != 'Step':
              data += line.split()[position] + ' '
with open(outputfile,'w') as fwrite:
    fwrite.writelines(data)
print(data)   
