# /usr/bin/env python3
import os
import string
import re
import sys


print('python extraQ.py Generate_whole_directory_name Target_whole_directory Target_secondary_directory Generate_secondary directory EnergyorQ')

PdbID = sys.argv[1]
Temp = sys.argv[2]
Work = sys.argv[3]
Num = sys.argv[4]
Dir_target = '/home/xun/Downloads/download/' + PdbID +'/' + PdbID +'-' + Temp +'-'+ Work + '/' + PdbID + '-' + Temp +'-' + Work +'-T_Energy_Best_structure'
Dir_Work = '/home/xun/Downloads'
os.chdir("%s"%(Dir_target))
for x in range(20):
   Pdb_file = PdbID + '-' + Temp + '-' + Work + str(x)  
   rnative_file = 'rnative' + str(x) + '.dat'
   os.system("python %s/GetCACADistancesFile_multiChain_part.py  %s %s %s"%(Dir_Work,Pdb_file,rnative_file,Num)) 



