# /usr/bin/env python3
import os
import string
import re
import sys


print('python read_seq.py inpputfile outputfile')
inputfile = sys.argv[1] + '.pdb'
outputfile = sys.argv[2] + '.seq'
chain = sys.argv[3]
with open(inputfile,'r') as fopen:
   lines = fopen.readlines()
data = ''
for line in lines:
     if line.split()[0] == 'ATOM':
        Numi = line.split()[5]
        break
Num = int(Numi) - 1
print Num
with open(outputfile,'w') as fwrite:
   for line in lines:
     #print(line)
     if line.find('END') == 0:
        break
     elif line.split()[0] == 'ATOM':
        #print line
        if line.split()[4] == chain:
         #print line
         if line.split()[2] == 'C':
           if int(line.split()[5]) - Num > 1:
              jj = int(line.split()[5]) - Num - 1
              if jj != 0:
               for i in range(jj):
                data += '-'
           elif  int(line.split()[5]) - Num < 1:
              continue
          # print data
           if line.split()[3] == 'ALA'  :
              data += 'A'
           elif line.split()[3] == 'VAL':
              data += 'V'
           elif line.split()[3] == 'LEU':
              data += 'L'
           elif line.split()[3] == 'ILE':
              data += 'I'
           elif line.split()[3] == 'PRO':
              data += 'P'
           elif line.split()[3] == 'PHE':
              data += 'F'
           elif line.split()[3] == 'TRP':
              data += 'W'
           elif line.split()[3] == 'MET':
              data += 'M'
           elif line.split()[3] == 'GLY':
              data += 'G'
           elif line.split()[3] == 'SER':
              data += 'S'
           elif line.split()[3] == 'THR':
              data += 'T'
           elif line.split()[3] == 'CYS':
              data += 'C'
           elif line.split()[3] == 'TYR':
              data += 'Y'
           elif line.split()[3] == 'ASN':
              data += 'N'
           elif line.split()[3] == 'GLN':
              data += 'Q'
           elif line.split()[3] == 'ASP':
              data += 'D'
           elif line.split()[3] == 'GLU':
              data += 'E'
           elif line.split()[3] == 'LYS':
              data += 'K'
           elif line.split()[3] == 'ARG':
              data += 'R'
           elif line.split()[3] == 'HIS':
              data += 'H'
           else:
              data += '-'
           Num = int(line.split()[5])
           Numf = line.split()[5] 
       
   data += '\n'
  # line = Numi + ' ' + Numf
   fwrite.writelines(data)
  # fwrite.writelines(line)
print data
print line
