import os
import sys
import random
import numpy as np
print('*py ')
pathT = sys.argv[1]
subdir = sys.argv[2]
pathR = sys.argv[3]
prefix = sys.argv[4]
dumpfile = sys.argv[5]
Oligmerfile = sys.argv[6]
seqfile = sys.argv[7]
num_windows = int(sys.argv[8])
fibersize = int(sys.argv[9])
squeue = 0
data = ''
for i in range(num_windows):
    
    #print pathR
    os.chdir(pathR)
    indexfile = pathT + '/' + subdir + str(i+1) + '/' + Oligmerfile 
    targetfile = pathT + '/' + subdir + str(i+1) + '/' + dumpfile
    supplementfile = pathT + '/' + subdir + str(i+1) + '/' + seqfile
    list_os = np.loadtxt(indexfile)
    print list_os
    print str(i+1)
    #with open(indexfile,'r') as fopen:
    #  for line in fopen.readline():
    #   print line
    #   if int(line) == fibersize:
    for j in range(len(list_os)):
    #  print os[j]
      if list_os[j] == fibersize:
        os.system("python /home/xun/Downloads/AWSEM/awsemmd-amylometer/results_analysis_tools/BuildAllAtomsFromLammps_seq.py %s %s.pdb %s %s"%(targetfile,str(squeue),supplementfile,str(j)))
        squeue += 1
        data += str(squeue) + ' ' + str(i+1) + ' ' + str(j) + '\n'
        print str(i+1)
print squeue
os.system("rm *psf") 
outputfile = pathR + '/' + "index.txt"
with open(outputfile,'w') as fwrite:
   fwrite.writelines(data)
