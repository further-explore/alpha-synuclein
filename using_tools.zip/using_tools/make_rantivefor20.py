# /usr/bin/env python3

import os
import re
import string
import sys
PdbID = sys.argv[1]
Temp = sys.argv[2]
Work = sys.argv[3]
Appd = sys.argv[4]
if Work == 'ER':
   Work_whole = PdbID + '-' + Work 
else:
   Work_whole = PdbID + '-' + Temp + '-' +Work 
Dir_resultmaker = '/home/xc25/AWSEM/awsemmd-amylometer/results_analysis_tools'
SumD = Work_whole + '-' +Appd  
Dir_results = '/scratch/xc25/download/'+ PdbID +'/' + Work_whole
os.chdir("%s"%(Dir_results))
os.system("mkdir rnative")
Dir_rnative = Dir_results + '/rnative' 
Dir_target = '/scratch/xc25/'+PdbID +'/' + SumD

os.chdir("%s"%(Dir_rnative))
for i in range(20):
   File = Work_whole + str(i)
   Dir1 = Dir_target + '/' + File
   with open(Dir1 + '/'+PdbID + '.psspred') as fopen:
    for line in fopen.readlines():
     line = line.rstrip('\n')
     break
   Num = str(len(line)+1 )
   x = 0
   Energy_file = Dir1 +'/energy.dat'
   with open (Energy_file,'r+') as fopen:
        for line in fopen.readlines():
           if line.split()[0] != 'Step':
            z = float(line.split()[16])
            y = line.split()[0]
            if z < x :
               x = z
               Energy = str(z)
               print(Energy)
               snapshot = str (int(y)/1000)
   os.chdir("%s"%(Dir_rnative))
   os.system('python %s/BuildAllAtomsFromLammps_seq.py %s/dump.lammpstrj %s.pdb %s/%s-HO.seq %s'%(Dir_resultmaker,Dir1,File,Dir1,PdbID,snapshot))
   os.system("python /home/xc25/GetCACADistancesFile_multiChain_part.py %s rnative-%s.dat %s"%(File,File,Num))
   os.system("rm  *.psf *.pdb")
  
